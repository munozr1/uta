> Last hw it was mentioned that the code would not run so i am providing a list of commands i used
> 1 late day plz
  
## Commands Used
* ```conda create --name 3380hw5```
* ```conda activate 3380hw5```
* ```pip3 install numpy```
* ```pip3 install matplotlib```
>all other libs required are installed by default with anaconda
* ```python3 QRFactorization.py```
* ```python3 LeastSquares.py```


## Viewing Least Squares Figures
To view the least squares figures run the program and after inspecting the first
chart, close it and the second chart will appear.
