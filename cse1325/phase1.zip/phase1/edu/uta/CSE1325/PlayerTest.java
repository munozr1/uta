package edu.uta.CSE1325;

/**
 * Tests the player class for functionality
 */
public class PlayerTest {
    public static void main(String[] args) {
        Weapon Blunt_Sword = new Weapon("Blunt Sword", "1d2", 0);
        Weapon Great_Blunt_Sword = new Weapon("Great Blunt Sword", "3d6", 0);
        Player player1 = new Player(Blunt_Sword, "Rodrigo Munoz", 1, 8, 10, 100, 5,
                6, 8);
        Player player2 = new Player(Great_Blunt_Sword, "Player 2", 1, 2, 10, 100, 3,
                5, 8);

        System.out.println(player1.toString());
        System.out.println(player2.toString());
        System.out.println("helloworld");
        player2.attack(player1);
    }
}
