package edu.uta.CSE1325.Models;

enum MonsterEnum {
    Humanoid, Fiend, Dragon;
}
