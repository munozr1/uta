package edu.uta.CSE1325;

enum MonsterEnum {
    Humanoid, Fiend, Dragon;
}
