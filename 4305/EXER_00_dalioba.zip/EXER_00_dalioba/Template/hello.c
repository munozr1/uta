// Dalio, Brian A.
// dalioba
// 2023-08-01
//----------------------------------------------------------------
#include <stdio.h>

//----------------------------------------------------------------
int main()
{
  // Oh, boy!
  printf( "Hello, world!  My C development environment WORKS!\n" );

  // No problems detected, so exit with status code 0 for SUCCESS.
  return 0;
}

//----------------------------------------------------------------
