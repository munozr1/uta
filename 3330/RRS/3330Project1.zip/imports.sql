.import Train.csv Train
.import Train_status.csv Train_status
.import Passenger-1.csv Passenger
.import booked-1.csv Booked
